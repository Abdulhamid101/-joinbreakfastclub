import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { drinks, shop } from "../data/drinks";

const STORAGE_KEY = "bc-cart-v1";
const CartContext = createContext(null);

export const formatNaira = (n) => "₦" + Math.round(n).toLocaleString("en-NG");

export const lineKey = (id, size) => `${id}::${size}`;

function loadCart() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    // Drop anything that no longer exists or is sold out, and re-price from
    // the current menu so stale prices in someone's browser never stick.
    return parsed
      .map((line) => {
        const drink = drinks.find((d) => d.id === line.id && d.available);
        const size = drink?.sizes.find((s) => s.label === line.size);
        if (!drink || !size || !(line.qty > 0)) return null;
        return { id: drink.id, size: size.label, qty: Math.min(line.qty, 20) };
      })
      .filter(Boolean);
  } catch {
    return [];
  }
}

export function CartProvider({ children }) {
  const [lines, setLines] = useState(loadCart);
  const [isOpen, setOpen] = useState(false);
  const [fulfilment, setFulfilment] = useState("pickup");

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
    } catch {
      /* private mode etc. — cart still works for this visit */
    }
  }, [lines]);

  const value = useMemo(() => {
    const items = lines.map((line) => {
      const drink = drinks.find((d) => d.id === line.id);
      const price = drink.sizes.find((s) => s.label === line.size).price;
      return { ...line, key: lineKey(line.id, line.size), drink, price, total: price * line.qty };
    });
    const count = items.reduce((n, i) => n + i.qty, 0);
    const subtotal = items.reduce((n, i) => n + i.total, 0);
    const deliveryFee = fulfilment === "delivery" && count > 0 ? shop.deliveryFee : 0;

    return {
      items,
      count,
      subtotal,
      deliveryFee,
      total: subtotal + deliveryFee,
      fulfilment,
      setFulfilment,
      isOpen,
      open: () => setOpen(true),
      close: () => setOpen(false),
      add(id, size, qty = 1) {
        setLines((prev) => {
          const existing = prev.find((l) => l.id === id && l.size === size);
          if (existing) {
            return prev.map((l) =>
              l === existing ? { ...l, qty: Math.min(l.qty + qty, 20) } : l
            );
          }
          return [...prev, { id, size, qty }];
        });
      },
      setQty(key, qty) {
        setLines((prev) =>
          prev
            .map((l) => (lineKey(l.id, l.size) === key ? { ...l, qty: Math.min(qty, 20) } : l))
            .filter((l) => l.qty > 0)
        );
      },
      remove(key) {
        setLines((prev) => prev.filter((l) => lineKey(l.id, l.size) !== key));
      },
      clear: () => setLines([]),
    };
  }, [lines, isOpen, fulfilment]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside <CartProvider>");
  return ctx;
}
