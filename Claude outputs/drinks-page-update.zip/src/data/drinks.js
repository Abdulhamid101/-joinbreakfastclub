// Drinks shop — everything you'd want to change lives in this file.
// Add a drink: copy one object in `drinks`, give it a unique `id`, done.
// Hide a drink temporarily: set `available: false` (shows "Sold out").

export const shop = {
  // ── Payments & orders ────────────────────────────────────────────────
  // Paystack public key from dashboard.paystack.com → Settings → API Keys.
  // Use pk_test_... while testing, pk_live_... to take real money.
  // Leave empty ("") to hide the "Pay now" button.
  paystackPublicKey: "",

  // WhatsApp number that receives orders, international format, digits
  // only, no + or spaces. e.g. "2348012345678". Leave "" to hide.
  whatsappNumber: "",

  // If both of the above are empty, orders go to this inbox by email.
  orderEmail: "hello@joinbreakfastclub.world",

  // ── Fulfilment ───────────────────────────────────────────────────────
  deliveryFee: 1500, // ₦, flat, within Abeokuta
  pickupLabel: "Pick up at the Saturday meetup",
  pickupDetail: "Free · ready when you arrive, 7:00 AM",
  deliveryLabel: "Deliver to me",
  deliveryDetail: "Within Abeokuta",
};

export const drinksPage = {
  eyebrow: "Breakfast Club Drinks",
  heading: "Fresh drinks, made for Saturday mornings.",
  sub: "Order ahead and grab yours at the meetup, or get it delivered anywhere in Abeokuta.",
  howItWorks: [
    { title: "Pick your drinks", body: "Choose a size, add to cart. Mix and match as much as you like." },
    { title: "Check out", body: "Pay securely online, or send the order to us on WhatsApp." },
    { title: "Sip", body: "Collect it at the Saturday meetup or have it brought to your door." },
  ],
  faqs: [
    {
      q: "When is pickup?",
      a: "Every Saturday at the community meetup from 7:00 AM. Your name will be on your cup.",
    },
    {
      q: "Where do you deliver?",
      a: "Anywhere within Abeokuta for a flat fee. We'll call to confirm your time before we head out.",
    },
    {
      q: "Can I order for a group or event?",
      a: "Yes — add everything to your cart, or email us for larger orders and partnerships.",
    },
  ],
};

export const categories = ["All", "Coffee", "Matcha", "Smoothies", "Teas & Juices"];

export const drinks = [
  {
    id: "iced-caramel-latte",
    name: "Iced Caramel Latte",
    category: "Coffee",
    description: "Double-shot espresso over chilled milk and ice, finished with a slow caramel drizzle.",
    tags: ["Caffeinated", "Contains dairy"],
    sizes: [
      { label: "Regular", price: 3500 },
      { label: "Large", price: 4500 },
    ],
    badge: "Bestseller",
    available: true,
    image: "", // optional: "/images/drinks/caramel-latte.jpg" replaces the illustration
    colors: { liquid: "#b07a4a", top: "#f3e2c7", accent: "#6b4226", bg: "#f6e7cf" },
  },
  {
    id: "iced-matcha-latte",
    name: "Iced Matcha Latte",
    category: "Matcha",
    description: "Ceremonial-grade matcha whisked smooth and poured over cold milk. Calm energy, no crash.",
    tags: ["Caffeinated", "Contains dairy"],
    sizes: [
      { label: "Regular", price: 4000 },
      { label: "Large", price: 5000 },
    ],
    badge: "",
    available: true,
    image: "",
    colors: { liquid: "#8cb04a", top: "#eef3dc", accent: "#4f7a1f", bg: "#e9f0d4" },
  },
  {
    id: "berry-sunrise-smoothie",
    name: "Berry Sunrise Smoothie",
    category: "Smoothies",
    description: "Strawberry, banana and a splash of yoghurt blended thick. Breakfast in a cup.",
    tags: ["No added sugar", "Contains dairy"],
    sizes: [
      { label: "Regular", price: 4000 },
      { label: "Large", price: 5000 },
    ],
    badge: "",
    available: true,
    image: "",
    colors: { liquid: "#e0566f", top: "#f7b3c0", accent: "#a8243f", bg: "#fbe0e3" },
  },
  {
    id: "zobo-hibiscus-iced-tea",
    name: "Zobo Hibiscus Iced Tea",
    category: "Teas & Juices",
    description: "Our take on the classic — hibiscus steeped with ginger, pineapple and clove, served ice cold.",
    tags: ["Dairy-free", "Caffeine-free"],
    sizes: [
      { label: "Regular", price: 2000 },
      { label: "Large", price: 2800 },
    ],
    badge: "Local favourite",
    available: true,
    image: "",
    colors: { liquid: "#8e1b3a", top: "#b8324f", accent: "#5c0f24", bg: "#f5dbe0" },
  },
  {
    id: "tropical-glow-juice",
    name: "Tropical Glow Juice",
    category: "Teas & Juices",
    description: "Fresh-pressed pineapple, orange and a kick of ginger. Bright, zesty, wakes you right up.",
    tags: ["Dairy-free", "Caffeine-free"],
    sizes: [
      { label: "Regular", price: 3000 },
      { label: "Large", price: 3800 },
    ],
    badge: "",
    available: true,
    image: "",
    colors: { liquid: "#fca10c", top: "#ffd06b", accent: "#fc5b0d", bg: "#fdebc8" },
  },
];
